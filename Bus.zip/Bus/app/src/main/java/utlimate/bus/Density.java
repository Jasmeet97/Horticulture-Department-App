package utlimate.bus;

import android.os.AsyncTask;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Density extends AppCompatActivity {


    TextView t1,t2,t3,t4,t5,t6,t7,t8,t9,t10;

    String greetings[];

    double lats[],lons[];
    int busnos[],dens[];
    String JSON_STRING;
    String json;

    JSONObject jsonObject;
    JSONArray jsonArray;

    double x = 20.00;
    double y = 80.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_density);



        t1 = (TextView)findViewById(R.id.den1);
        t2 = (TextView)findViewById(R.id.den2);
        t3 = (TextView)findViewById(R.id.den3);
        t4 = (TextView)findViewById(R.id.den4);
        t5 = (TextView)findViewById(R.id.den5);
        t6 = (TextView)findViewById(R.id.den6);
        t7 = (TextView)findViewById(R.id.den7);
        t8 = (TextView)findViewById(R.id.den8);
        t9 = (TextView)findViewById(R.id.den9);
        t10 = (TextView)findViewById(R.id.den10);



        getJSON(null);

        timer(null);


    }


    public void getJSON(View view) {
        new BackgroundTask().execute();

    }

    class BackgroundTask extends AsyncTask<Void, Void, String> {

        String json_url;

        @Override
        protected void onPreExecute() {

            json_url = "http://ultimatecorp.esy.es/jsonbus.php";

        }

        @Override
        protected String doInBackground(Void... params) {

            try {
                URL url = new URL(json_url);

                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                InputStream inputStream = httpURLConnection.getInputStream();

                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                StringBuilder stringBuilder = new StringBuilder();

                while ((JSON_STRING = bufferedReader.readLine()) != null) {
                    stringBuilder.append(JSON_STRING + "\n");

                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return stringBuilder.toString().trim();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {

            json = result;


            try {
                jsonObject = new JSONObject(json);
                jsonArray = jsonObject.getJSONArray("server_response");


                int count = 0, i = 0;
                int question, option3;
                double option1, option2;

                busnos = new int[50];
                lats = new double[50];
                lons = new double[50];
                dens = new int[50];


                while (count < jsonArray.length()) {
                    JSONObject JO = jsonArray.getJSONObject(count);

                    question = JO.getInt("busno");// key => used in php
                    option1 = JO.getDouble("latitude");
                    option2 = JO.getDouble("longitude");
                    option3 = JO.getInt("density");


                    count++;

                    busnos[i] = question;
                    lats[i] = option1;
                    lons[i] = option2;
                    dens[i] = option3;

                    i++;
                }

                greetings = new String[6];
                greetings[0] = " ";
                greetings[1] = "All yours!";
                greetings[2] = "Moderate";
                greetings[3] = "Kind'a crowded";
                greetings[4] = "Crowded";
                greetings[5] = "A'int stopping!";

                int d1 = dens[0];

                if(lats[0] == x && lons[0] == y)
                {
                    t1.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    t1.setText(greetings[d1]);
                }



                int d2 = dens[1];

                if(lats[1] == x && lons[1] == y)
                {
                    t2.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    t2.setText(greetings[d2]);
                }


                int d3 = dens[2];

                if(lats[2] == x && lons[2] == y)
                {
                    t3.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    t3.setText(greetings[d3]);
                }


                int d4 = dens[3];

                if(lats[3] == x && lons[3] == y)
                {
                    t4.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    t4.setText(greetings[d4]);
                }


                int d5 = dens[4];

                if(lats[4] == x && lons[4] == y)
                {
                    t5.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    t5.setText(greetings[d5]);
                }


                int d6 = dens[5];

                if(lats[5] == x && lons[5] == y)
                {
                    t6.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    t6.setText(greetings[d6]);
                }


                int d7 = dens[6];

                if(lats[6] == x && lons[6] == y)
                {
                    t7.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    t7.setText(greetings[d7]);
                }


                int d8 = dens[7];

                if(lats[7] == x && lons[7] == y)
                {
                    t8.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    t8.setText(greetings[d8]);
                }


                int d9 = dens[8];

                if(lats[8] == x && lons[8] == y)
                {
                    t9.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    t9.setText(greetings[d9]);
                }


                int d10 = dens[9];

                if(lats[9] == x && lons[9] == y)
                {
                    t10.setText("Bus in Danger!!!");

                    Toast.makeText(getBaseContext(), "Bus in danger", Toast.LENGTH_SHORT).show();
                }

                else
                {
                    t10.setText(greetings[d10]);
                }



            } catch (JSONException e) {
                e.printStackTrace();
            }




        }
    }


    void timer(View view)
    {
        new CountDownTimer(2000, 1000){
            public void onTick(long millisUntilFinished){

                //Toast.makeText(getApplicationContext(),"efqwfe",Toast.LENGTH_LONG).show();
            }
            public  void onFinish(){

                getJSON(null);
                timer(null);

            }
        }.start();
    }

}
