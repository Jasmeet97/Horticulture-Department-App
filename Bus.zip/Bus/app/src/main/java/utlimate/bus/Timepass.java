package utlimate.bus;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Timepass extends FragmentActivity {

    ImageButton i1,i2,i3,i4,i5;
    String MY_PREFS_NAME = "Name";
    TextView t;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timepass);

        i1 = (ImageButton)findViewById(R.id.imageButton);
        i2 = (ImageButton)findViewById(R.id.imageButton2);
        i3 = (ImageButton)findViewById(R.id.imageButton3);
        i4 = (ImageButton)findViewById(R.id.imageButton4);
        i5 = (ImageButton)findViewById(R.id.imageButton5);
        t = (TextView)findViewById(R.id.username);

        t.setText("Hi "+getUserName()+"!");

    }

    /*This function calls the google map on click of button*/
    public void map(View v)
    {
        Intent i = new Intent(Timepass.this,MainActivity.class);
        startActivity(i);
    }

    public void density(View v)
    {
        Intent i = new Intent(Timepass.this,Density.class);
        startActivity(i);
    }

    public void developer(View v)
    {
        Intent i = new Intent(Timepass.this,Developer.class);
        startActivity(i);
    }


    public void seat(View v)
    {
        Intent i = new Intent(Timepass.this,Seat.class);
        startActivity(i);
    }


    public void location(View v)
    {
        Intent i = new Intent(Timepass.this,Location.class);
        startActivity(i);
    }

    String getUserName()
    {
        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String usrname = prefs.getString("first_name",null);

        return usrname;
    }
}
